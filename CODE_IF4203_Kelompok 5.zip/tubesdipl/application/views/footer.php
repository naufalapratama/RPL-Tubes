</div>
<script src="<?= base_url(''); ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url(''); ?>assets/js/jquery-3.5.1.min.js"></script>
<script src="<?= base_url(''); ?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(''); ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url(''); ?>assets/js/bs-init.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
<script src="<?= base_url(''); ?>assets/js/creative.js"></script>
<script src="<?= base_url(''); ?>assets/js/Faq-by-pomdre.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
<script src="<?= base_url(''); ?>assets/js/Simple-Slider.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
</body>

</html>